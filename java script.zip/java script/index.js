alert('Olá,  por favor responda as seguintes perguntas');

let seu_nome;
let ano_nascimento;
let sua_idade;


seu_nome = prompt('Qual seu nome?');

ano_nascimento = prompt ('Em que ano nasceu?');

alert (` bem ${seu_nome},  atualmente você tem  ${sua_idade = 2022 - ano_nascimento} anos de idade`);
